package com.nbmediation.sdk.mobileads;

public enum KSNativeType {
    KS_NATIVE_TYPE_NORMAL,
    KS_NATIVE_TYPE_DRAW,
    KS_NATIVE_TYPE_CDRAW;
}
